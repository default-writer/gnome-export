# BaBar
GNOME Shell extension

App grid, favorites, workspaces & tasks in top panel

https://extensions.gnome.org/extension/4000/babar/

![ezgif com-gif-maker](https://user-images.githubusercontent.com/23138504/115955697-72373f00-a4f8-11eb-8bcb-059d920de888.gif)
