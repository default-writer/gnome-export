# gnome-rounded-corners

Adds rounded corners to every monitor in Gnome.

